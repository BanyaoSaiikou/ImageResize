from PIL import Image

def resize_pgm(input_file, output_file, size):
    with open(input_file, 'rb') as img_file:
        pgm_image = Image.open(img_file)
        resized_image = pgm_image.resize(size)
        resized_image.save(output_file)

resize_pgm('/home/cwh/Downloads/zhanghuanhuanpython/result/black_640.pgm', '/home/cwh/Downloads/zhanghuanhuanpython/result/black_560_2.pgm', (560, 420))
resize_pgm('/home/cwh/Downloads/zhanghuanhuanpython/result/Sample_1024.pgm', '/home/cwh/Downloads/zhanghuanhuanpython/result/Sample_560_2.pgm', (560, 420))